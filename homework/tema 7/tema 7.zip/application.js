$(document).ready(function() {

$('#addCharacter').on('click', function() {
    $(this).remove();
    $('#crew-form').fadeIn();
});

$("#picture").keyup(function(){
  var inputVal = $(this).val();
  $("#img").attr("src", inputVal);
});

$('.add-row').on('click', function () {
                var name = $("#MovieTitle").val();
                var actorName = $("#actorName").val();
                var picture = $("#img");
                var markup = "<tr><td><input type='checkbox' name='record'></td><td>" + name + "</td><td>" 
                + actorName + "</td><td></td></tr>";
                $("table tbody").append(markup);
                $("td").last().prepend(picture);
                $("input").val('');
                $("#tabel").show();
                $("#img").show();
            });
$('.remove').on('click', function() {
        $("table tbody").find('input[name="record"]').each(function(){
            if($(this).is(":checked")){
                $(this).parents("tr").remove();
            }
        });
        })
});

$('input').on('focusin', function() {
    $(this).parent().find('label').addClass('active');
  });
  
  $('input').on('focusout', function() {
    if (!this.value)  {
      $(this).parent().find('label').removeClass('active');
    }
  });
 
