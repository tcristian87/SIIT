function AddTask() {  
      this.taskName=  $("#taskName").val();
      this.TaskDescription = $("#TaskDescription").val();
      this.Status = $("#Status").val();
      this.StartDate = $("#StartDate").val();
      this.DueDate = $("#DueDate").val();
      this.AsignetUser = $("#AsignetUser").val();
       this.butoane =  $('#addTask');
      this.init();
      
}
 
let row = `<tr>
      <td>${this.taskName}</td>
      <td>${TaskDescription}</td>
      <td>${Status}</td>
      <td>${StartDate}</td>
      <td>${DueDate}</td>
      <td>${AsignetUser}</td>
      <td><button class="remove">Remove</button><button class="edit">Edit</button></td></tr>`;

AddTask.prototype.init = function () {   // metoda de initializare
   this.addeventListener();

}

AddTask.prototype._button = function (todos) {
    console.log("add task merge");   
     $("#table tbody").append(row);
};
   
  AddTask.prototype.addeventListener = function () {
    console.log('thisisisisis');
    this.butoane.on("click", this._button);
  }
